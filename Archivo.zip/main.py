import PySimpleGUI as sg
import pandas as pd
import os
import json
import matplotlib.pyplot as plt

# Nombre de los archivos donde se guardarán los eventos y participantes
EVENTOS_FILE = 'eventos.csv'
PARTICIPANTES_FILE = 'participantes.csv'
CONFIG_FILE = 'configuracion.json'

# Función para verificar usuario
def verificar_usuario(usuario, contrasena):
    try:
        with open('usuarios.txt', 'r') as file:
            for line in file:
                user, password = line.strip().split(',')
                if user == usuario and password == contrasena:
                    return True
    except FileNotFoundError:
        sg.popup('Error', 'El archivo de usuarios no se encontró.')
    return False

# Crear la ventana de login
def ventana_login():
    layout_login = [
        [sg.Text('Nombre de Usuario:'), sg.InputText(key='-USUARIO-')],
        [sg.Text('Contraseña:'), sg.InputText(key='-CONTRASENA-', password_char='*')],
        [sg.Button('Iniciar Sesión'), sg.Button('Cancelar')]
    ]
    window_login = sg.Window('Login', layout_login)

    while True:
        event, values = window_login.read()
        if event == sg.WIN_CLOSED or event == 'Cancelar':
            window_login.close()
            return None  # Cerrar el programa si se cancela

        if event == 'Iniciar Sesión':
            usuario = values['-USUARIO-']
            contrasena = values['-CONTRASENA-']
            if verificar_usuario(usuario, contrasena):
                window_login.close()
                return True  # Login exitoso
            else:
                sg.popup('Error', 'Usuario o contraseña incorrectos. Intente nuevamente.')

# Función para cargar eventos desde el archivo
def cargar_eventos():
    if os.path.exists(EVENTOS_FILE):
        try:
            eventos_df = pd.read_csv(EVENTOS_FILE)
            return eventos_df['Nombre'].tolist()  # Suponiendo que la columna se llama 'Nombre'
        except Exception as e:
            sg.popup('Error al cargar eventos', str(e))
            return []
    return []

# Función para cargar participantes desde el archivo
def cargar_participantes():
    if os.path.exists(PARTICIPANTES_FILE):
        try:
            participantes_df = pd.read_csv(PARTICIPANTES_FILE)
            return participantes_df.to_dict(orient='records')  # Cargar como lista de diccionarios
        except Exception as e:
            sg.popup('Error al cargar participantes', str(e))
            return []
    return []

# Función para cargar configuración desde el archivo
def cargar_configuracion():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as file:
            return json.load(file)
    else:
        # Si el archivo no existe, devolver valores predeterminados
        return {
            'solicitar_imagenes': False,
            'modificar_registros': False,
            'eliminar_registros': False,
            'validar_aforo': False
        }

# Función para guardar configuración en el archivo
def guardar_configuracion(configuracion):
    with open(CONFIG_FILE, 'w') as file:
        json.dump(configuracion, file)

# Función para guardar eventos en el archivo
def guardar_evento(nombre, fecha, cupo, lugar, hora, imagen):
    try:
        # Leer el archivo existente
        if os.path.exists(EVENTOS_FILE):
            eventos_df = pd.read_csv(EVENTOS_FILE)
            # Verificar si el evento ya existe
            if nombre in eventos_df['Nombre'].values:
                sg.popup('Error', 'Ya existe un evento con ese nombre.')
                return

        # Crear un nuevo DataFrame con el nuevo evento
        nuevo_evento = pd.DataFrame({'Nombre': [nombre], 'Fecha': [fecha], 'Cupo': [cupo], 'Lugar': [lugar], 'Hora': [hora], 'Imagen': [imagen]})

        # Guardar el nuevo evento
        if os.path.exists(EVENTOS_FILE):
            nuevo_evento.to_csv(EVENTOS_FILE, mode='a', header=False, index=False)
        else:
            nuevo_evento.to_csv(EVENTOS_FILE, index=False)

    except ValueError:
        sg.popup('Error', 'Se ingresaron valores no numéricos en el campo “cupo”.')
    except Exception as e:
        sg .popup('Error al guardar el evento', str(e))

# Función para guardar participantes en el archivo
def guardar_participante(participante):
    try:
        # Leer el archivo existente
        if os.path.exists(PARTICIPANTES_FILE):
            participantes_df = pd.read_csv(PARTICIPANTES_FILE)
            # Verificar si el número de documento ya existe
            if participante['NumeroDocumento'] in participantes_df['NumeroDocumento'].values:
                sg.popup('Error', 'Ya existe un participante con ese número de documento.')
                return

        # Crear un nuevo DataFrame con el nuevo participante
        nuevo_participante = pd.DataFrame([participante])

        # Guardar el nuevo participante
        if os.path.exists(PARTICIPANTES_FILE):
            nuevo_participante.to_csv(PARTICIPANTES_FILE, mode='a', header=False, index=False)
        else:
            nuevo_participante.to_csv(PARTICIPANTES_FILE, index=False)

    except ValueError:
        sg.popup('Error', 'Se ingresaron valores no numéricos en el campo “número de documento”.')
    except Exception as e:
        sg.popup('Error al guardar el participante', str(e))

# Función para analizar la asistencia de participantes
def analizar_asistencia(participantes, eventos):
    participantes_asistieron_todos = []
    participantes_asistieron_al_menos_uno = []
    participantes_asistieron_solo_primer_evento = []

    if eventos:
        primer_evento = eventos[0]
        eventos_asistidos = {p['NumeroDocumento']: 0 for p in participantes}

        for p in participantes:
            if p['Evento'] == primer_evento:
                eventos_asistidos[p['NumeroDocumento']] += 1
                participantes_asistieron_al_menos_uno.append(p['Nombre'])

            for evento in eventos:
                if p['Evento'] == evento:
                    eventos_asistidos[p['NumeroDocumento']] += 1

        for numero_documento, cantidad in eventos_asistidos.items():
            if cantidad == len(eventos):
                participantes_asistieron_todos.append(numero_documento)
            elif cantidad == 1 and eventos_asistidos[numero_documento] == 1:
                participantes_asistieron_solo_primer_evento.append(numero_documento)

    return participantes_asistieron_todos, list(set(participantes_asistieron_al_menos_uno)), participantes_asistieron_solo_primer_evento

# Función para generar gráficos
def generar_graficos(participantes, eventos):
    # Gráfico de distribución de participantes por tipo
    df_participantes = pd.DataFrame(participantes)
    tipo_participante_counts = df_participantes['TipoParticipante'].value_counts()
    tipo_participante_counts.plot(kind='bar', title='Distribución de Participantes por Tipo')
    plt.xlabel('Tipo de Participante')
    plt.ylabel('Cantidad')
    plt.show()

    # Gráfico de participantes por evento
    participantes_por_evento = df_participantes['Evento'].value_counts()
    participantes_por_evento.plot(kind='bar', title='Participantes por Evento')
    plt.xlabel('Evento')
    plt.ylabel('Cantidad de Participantes')
    plt.show()

    # Gráfico de eventos por fecha
    df_eventos = pd.DataFrame(eventos)
    eventos_por_fecha = df_eventos['Fecha'].value_counts()
    eventos_por_fecha.plot(kind='bar', title='Eventos por Fecha')
    plt.xlabel('Fecha')
    plt.ylabel('Cantidad de Eventos')
    plt.show()

# Llamar a la ventana de login
if ventana_login():
    # Cargar configuración
    configuracion = cargar_configuracion()

    # Crear el layout de la ventana principal con pestañas
    layout = [
        [sg.TabGroup([
            [sg.Tab('Eventos', [
                [sg.Text('Nombre del Evento:'), sg.InputText(key='-NOMBRE_EVENTO-')],
                [sg.Text('Fecha (DD/MM/AAAA):'), sg.InputText(key='-FECHA_EVENTO-')],
                [sg.Text('Cupo:'), sg.InputText(key='-CUPO_EVENTO-')],
                [sg.Text('Lugar:'), sg.InputText(key='-LUGAR_EVENTO-')],
                [sg.Text('Hora (HH:MM):'), sg.InputText(key='-HORA_EVENTO-')],
                [sg.Text('Selecciona una imagen (opcional):'), sg.Input(key='-FILE_EVENT-', enable_events=True), sg.FileBrowse('Buscar')],
                [sg.Button('Agregar Evento'), sg.Button('Modificar Evento'), sg.Button('Eliminar Evento'), sg.Button('Ver Eventos')],
                [sg.Listbox(values=[], size=(60, 10), key='-LISTA_EVENTOS-', select_mode= sg.LISTBOX_SELECT_MODE_SINGLE)],
                [sg.Image(key='-IMAGE_EVENT-', size=(200, 200))],
            ]),
            sg.Tab('Participantes', [
                [sg.Text('Seleccione un Evento para Participantes:')],
                [sg.Listbox(values=[], size=(60, 5), key='-LISTA_EVENTOS_PARTICIPANTES-', select_mode=sg.LISTBOX_SELECT_MODE_SINGLE)],
                [sg.Text('Nombre Participante:'), sg.InputText(key='-NOMBRE_PARTICIPANTE-')],
                [sg.Text('Tipo de Documento:'), sg.InputText(key='-TIPO_DOCUMENTO-')],
                [sg.Text('Número de Documento:'), sg.InputText(key='-NUMERO_DOCUMENTO-')],
                [sg.Text('Teléfono:'), sg.InputText(key='-TELEFONO-')],
                [sg.Text('Dirección:'), sg.InputText(key='-DIRECCION-')],
                [sg.Text('Tipo de Participante:'), sg.InputText(key='-TIPO_PARTICIPANTE-')],
                [sg.Text('Selecciona una imagen (opcional):'), sg.Input(key='-FILE_PARTICIPANTE-', enable_events=True), sg.FileBrowse('Buscar')],
                [sg.Button('Agregar Participante'), sg.Button('Modificar Participante'), sg.Button('Eliminar Participante'), sg.Button('Ver Participantes')],
                [sg.Listbox(values=[], size=(60, 10), key='-LISTA_PARTICIPANTES-', select_mode=sg.LISTBOX_SELECT_MODE_SINGLE)],
                [sg.Image(key='-IMAGE_PARTICIPANTE-', size=(200, 200))],
            ]),
            sg.Tab('Configuración', [
                [sg.Text('Configuración')],
                [sg.Checkbox('Solicitar imágenes para eventos', key='-SOLICITAR_IMAGENES-', default=configuracion['solicitar_imagenes'])],
                [sg.Checkbox('Modificar registros', key='-MODIFICAR_REGISTROS-', default=configuracion['modificar_registros'])],
                [sg.Checkbox('Eliminar registros', key='-ELIMINAR_REGISTROS-', default=configuracion['eliminar_registros'])],
                [sg.Checkbox('Validar aforo al agregar participantes', key='-VALIDAR_AFORO-', default=configuracion['validar_aforo'])],
                [sg.Button('Guardar', key='-GUARDAR-')],
            ]),
            sg.Tab('Análisis', [
                [sg.Text('Participantes que asistieron a todos los eventos:')],
                [sg.Listbox(values=[], size=(60, 5), key='-PARTICIPANTES_TODOS-', select_mode=sg.LISTBOX_SELECT_MODE_SINGLE)],
                [sg.Text('Participantes que asistieron a al menos un evento:')],
                [sg.Listbox(values=[], size=(60, 5), key='-PARTICIPANTES_UNO-', select_mode=sg.LISTBOX_SELECT_MODE_SINGLE)],
                [sg.Text('Participantes que asistieron solo al primer evento:')],
                [sg.Listbox(values=[], size=(60, 5), key='-PARTICIPANTES_PRIMER-', select_mode=sg.LISTBOX_SELECT_MODE_SINGLE)],
                [sg.Button('Analizar Asistencia')],
                [sg.Button('Generar Gráficos', key='-GENERAR_GRAFICOS-')],
            ])]
        ])]
    ]

    window = sg.Window('Gestor de Eventos y Participantes', layout)

    # Listas para almacenar eventos y participantes
    eventos = cargar_eventos()
    participantes = cargar_participantes()

    # Función para actualizar la visualización de la lista con los participantes
    def actualizar_lista_participantes():
        window['-LISTA_PARTICIPANTES-'].update(participantes)

    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED:
            break

        # Gestión de eventos
        if event == 'Agregar Evento':
            nombre_evento = values['-NOMBRE_EVENTO-']
            fecha_evento = values['-FECHA_EVENTO-']
            cupo_evento = values['-CUPO_EVENTO-']
            lugar_evento = values['-LUGAR_EVENTO-']
            hora_evento = values['-HORA_EVENTO-']
            imagen_evento = values['-FILE_EVENT-'] if values['-FILE_EVENT-'] else None  # Imagen opcional

            # Validar que todos los campos estén llenos
            if (nombre_evento and fecha_evento and cupo_evento and lugar_evento and hora_evento):
                guardar_evento(nombre_evento, fecha_evento, cupo_evento, lugar_evento, hora_evento, imagen_evento)
                eventos.append(nombre_evento)  # Ag regar a la lista visual
                window['-LISTA_EVENTOS-'].update(values=eventos)
                window['-LISTA_EVENTOS_PARTICIPANTES-'].update(values=eventos)  # Actualizar lista de eventos para participantes
                # Limpiar los campos
                window['-NOMBRE_EVENTO-'].update('')
                window['-FECHA_EVENTO-'].update('')
                window['-CUPO_EVENTO-'].update('')
                window['-LUGAR_EVENTO-'].update('')
                window['-HORA_EVENTO-'].update('')
                window['-FILE_EVENT-'].update('')  # Limpiar la selección de imagen

        if event == 'Modificar Evento':
            if values['-LISTA_EVENTOS-']:
                indice_evento = eventos.index(values['-LISTA_EVENTOS-'][0])
                # Obtener los detalles del evento seleccionado
                detalles_evento = eventos[indice_evento].split(' | ')
                # Llenar los campos con los detalles del evento
                window['-NOMBRE_EVENTO-'].update(detalles_evento[0])
                window['-FECHA_EVENTO-'].update(detalles_evento[1].split(': ')[1])
                window['-CUPO_EVENTO-'].update(detalles_evento[2].split(': ')[1])
                window['-LUGAR_EVENTO-'].update(detalles_evento[3].split(': ')[1])
                window['-HORA_EVENTO-'].update(detalles_evento[4].split(': ')[1])
                # Mostrar la imagen asociada si existe
                if detalles_evento[5].split(': ')[1]:
                    window['-IMAGE_EVENT-'].update(filename=detalles_evento[5].split(': ')[1])  # Actualizar la imagen visualizada
                else:
                    window['-IMAGE_EVENT-'].update('')  # Limpiar la imagen si no hay ninguna asociada

                # Eliminar el evento original de la lista
                del eventos[indice_evento]
                window['-LISTA_EVENTOS-'].update(values=eventos)
                window['-LISTA_EVENTOS_PARTICIPANTES-'].update(values=eventos)  # Actualizar lista de eventos para participantes

        if event == 'Eliminar Evento':
            if values['-LISTA_EVENTOS-']:
                indice_evento = eventos.index(values['-LISTA_EVENTOS-'][0])
                del eventos[indice_evento]
                window['-LISTA_EVENTOS-'].update(values=eventos)
                window['-LISTA_EVENTOS_PARTICIPANTES-'].update(values=eventos)  # Actualizar lista de eventos para participantes
                window['-IMAGE_EVENT-'].update('')  # Limpiar la imagen

        if event == 'Ver Eventos':
            sg.popup('Tus eventos:', *eventos)

        # Gestión de participantes
        if event == 'Agregar Participante':
            if values['-LISTA_EVENTOS_PARTICIPANTES-']:
                evento_seleccionado = values['-LISTA_EVENTOS_PARTICIPANTES-'][0]
                nombre_participante = values['-NOMBRE_PARTICIPANTE-']
                tipo_documento = values['-TIPO_DOCUMENTO-']
                numero_documento = values['-NUMERO_DOCUMENTO-']
                telefono = values['-TELEFONO-']
                direccion = values['-DIRECCION-']
                tipo_participante = values['-TIPO_PARTICIPANTE-']
                imagen_participante = values['-FILE_PARTICIPANTE-'] if values['-FILE_PARTICIPANTE-'] else None  # Imagen opcional

                # Validar que todos los campos estén llenos
                if nombre_participante and tipo_documento and numero_documento and telefono and direccion and tipo_participante:
                    if values['-VALIDAR_AFORO-']:
                        # Validar aforo al agregar participantes
                        cupo_evento = int(evento_seleccionado.split(' | ')[2].split(': ')[1])
                        if len(participantes) < cupo_evento:
                            participante = {
                                'Nombre': nombre_participante,
                                'TipoDocumento': tipo_documento,
                                'NumeroDocumento': numero_documento, 
                                'Telefono': telefono,
                                'Direccion': direccion,
                                'TipoParticipante': tipo_participante,
                                'Evento': evento_seleccionado,
                                'Imagen': imagen_participante }
                            guardar_participante(participante)  # Guardar el participante en el archivo
                            participantes.append(participante)  # Agregar a la lista visual
                            actualizar_lista_participantes()  # Actualizar la lista visual
                            # Limpiar los campos
                            window['- NOMBRE_PARTICIPANTE-'].update('')
                            window['-TIPO_DOCUMENTO-'].update('')
                            window['-NUMERO_DOCUMENTO-'].update('')
                            window['-TELEFONO-'].update('')
                            window['-DIRECCION-'].update('')
                            window['-TIPO_PARTICIPANTE-'].update('')
                            window['-FILE_PARTICIPANTE-'].update('')  # Limpiar la selección de imagen
                        else:
                            sg.popup('Error', 'El aforo del evento ha sido alcanzado.')
                    else:
                        participante = {
                            'Nombre': nombre_participante,
                            'TipoDocumento': tipo_documento,
                            'NumeroDocumento': numero_documento,
                            'Telefono': telefono,
                            'Direccion': direccion,
                            'TipoParticipante': tipo_participante,
                            'Evento': evento_seleccionado,
                            'Imagen': imagen_participante
                        }
                        guardar_participante(participante)  # Guardar el participante en el archivo
                        participantes.append(participante)  # Agregar a la lista visual
                        actualizar_lista_participantes()  # Actualizar la lista visual
                        # Limpiar los campos
                        window['-NOMBRE_PARTICIPANTE-'].update('')
                        window['-TIPO_DOCUMENTO-'].update('')
                        window['-NUMERO_DOCUMENTO-'].update('')
                        window['-TELEFONO-'].update('')
                        window['-DIRECCION-'].update('')
                        window['-TIPO_PARTICIPANTE-'].update('')
                        window['-FILE_PARTICIPANTE-'].update('')  # Limpiar la selección de imagen
                else:
                    sg.popup('Error', 'Por favor, complete toda la información del participante.')

        if event == 'Modificar Participante':
            if values['-LISTA_PARTICIPANTES-']:
                indice_participante = participantes.index(values['-LISTA_PARTICIPANTES-'][0])
                # Obtener los detalles del participante seleccionado
                detalles_participante = participantes[indice_participante]
                # Llenar los campos con los detalles del participante
                window['-NOMBRE_PARTICIPANTE-'].update(detalles_participante['Nombre'])
                window['-TIPO_DOCUMENTO-'].update(detalles_participante['TipoDocumento'])
                window['-NUMERO_DOCUMENTO-'].update(detalles_participante['NumeroDocumento'])
                window['-TELEFONO-'].update(detalles_participante['Telefono'])
                window['-DIRECCION-'].update(detalles_participante['Direccion'])
                window['-TIPO_PARTICIPANTE-'].update(detalles_participante['TipoParticipante'])
                # Mostrar la imagen asociada si existe
                if detalles_participante['Imagen']:
                    window['-IMAGE_PARTICIPANTE-'].update(filename=detalles_participante['Imagen'])  # Actualizar la imagen visualizada
                else:
                    window['-IMAGE_PARTICIPANTE-'].update('')  # Limpiar la imagen si no hay ninguna asociada

        if event == 'Eliminar Participante':
            if values['-LISTA_PARTICIPANTES-']:
                indice_participante = participantes.index(values['-LISTA_PARTICIPANTES-'][0])
                del participantes[indice_participante]
                actualizar_lista_participantes()  # Actualizar la lista visual
                window['-IMAGE_PARTICIPANTE-'].update('')  # Limpiar la imagen

        if event == 'Ver Participantes':
            sg.popup('Tus participantes:', *[f"{p['Nombre']} - {p['NumeroDocumento']}" for p in participantes])

        # Gestión de análisis
        if event == 'Analizar Asistencia':
            participantes_todos, participantes_uno, participantes_primer = analizar_asistencia(participantes, eventos)
            window['-PARTICIPANTES_TODOS-'].update(participantes_todos)
            window['-PARTICIPANTES_UNO-'].update(participantes_uno)
            window['-PARTICIPANTES_PRIMER-'].update(participantes_primer)

        # Gestión de gráficos
        if event == '-GENERAR_GRAFICOS-':
            generar_graficos(participantes, eventos)

        # Gestión de configuración
        if event == '-GUARDAR-':
            configuracion['solicitar_imagenes'] = values['-SOLICITAR_IMAGENES-']
            configuracion['modificar_registros'] = values['-MODIFICAR_REGISTROS-']
            configuracion['eliminar_registros'] = values['-ELIMINAR_REGISTROS-']
            configuracion['validar_aforo'] = values['-VALIDAR_AFORO-']
            guardar_configuracion(configuracion)  # Guardar la configuración en el archivo
            sg.popup('Configuración guardada exitosamente.')

    window.close()